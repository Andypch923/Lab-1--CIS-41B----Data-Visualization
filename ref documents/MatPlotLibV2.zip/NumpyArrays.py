import pandas as pd
import numpy as np

print("\nsingle************************")
a = np.array(42)
print(a, 10*'-')
print(a.ndim)

print("\nlinear************************")
b = np.array([1, 2, 3, 4, 5])
print(b, 10*'-')
print(b[0], 10*'-')
print(b.ndim)

print("\n2D************************")
c = np.array([[1, 2, 3], [4, 5, 6]])
print(c,10*'-')
print(c[0,0], 10*'-')
print(c.ndim)

print("\n3D************************")
d = np.array([[ [1, 2, 3],[4, 5, 6] ], [ [1, 2, 3], [4, 5, 6] ]])
print(d, 10*'-')
print(d[0], 10*'-')
print(d[0,0], 10*'-')
print(d[0,0,0], 10*'-')
print(d.ndim)

print("\nindexing************************")
arr = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr[4:], 10*'-')
print(arr[-3:-1], 10*'-')
print(arr[1:5:2], 10*'-')

print("\nadd************************")
arr1 = np.array([1, 2, 3])
arr2 = np.array([1, 2, 3])
newarr = np.add(arr1, arr2)
print(newarr, 10*'-')

print("\nsum************************")
arr1 = np.array([1, 2, 3])
arr2 = np.array([1, 2, 3])
newarr = np.sum([arr1, arr2])
print(newarr, 10*'-')

print("\nprod************************")
arr = np.array([1, 2, 3, 4])
x = np.prod(arr)
print(x, 10*'-')

print("\ndif************************")
arr = np.array([10, 15, 25, 5])
newarr = np.diff(arr)
print(newarr, 10*'-')

print("\nnp2df************************")
nparray = np.array([[1, 1, 1], [2, 4, 8], [3, 9, 27], 
                  [4, 16, 64], [5, 25, 125], [6, 36, 216], 
                  [7, 49, 343]])
print(nparray,' '*10)
df = pd.DataFrame(data = nparray)
print(df, ' '*10)

print("\ndf2np************************")
np = df.to_numpy()
print(np)