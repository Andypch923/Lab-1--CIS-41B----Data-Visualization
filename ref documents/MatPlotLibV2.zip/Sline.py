import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ser = pd.Series([0,1,0,-1,0])
ser.plot.line()

plt.show()