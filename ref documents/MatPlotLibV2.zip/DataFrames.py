# assigning from dictionary
import pandas as pd

moondict = [{'Ceres':2.8, 'Pluto':39.5, 'Haumea':43.2, 'Eris':67.8,'Sedna':506.8}]
infodict = {'Dwarf':['Ceres', 'Pluto', 'Haumea', 'Eris','Sedna'],
        'Distance (AU)':[2.8,39.5,43.2,67.8,506.8]}
indexlist = ['index1','index2','index3','index4','index5']

print(25*'*')
df = pd.DataFrame(data = moondict)
print(df)

print(25*'*')
df1 = pd.DataFrame(moondict, columns=['Ceres', 'Pluto','Eris'])
df2 = pd.DataFrame(moondict, columns=['Haumea', 'Sedna'])
print(df1)
print(df2)

print(25*'*')
df = pd.DataFrame(infodict)
print(df)

print(25*'*')
df = pd.DataFrame(infodict, index=indexlist)
print (df)
print(*df.loc['index2'])
print(*df.iloc[1])
print (df[1:3])

print(25*'*')
moon1 = {'Ceres':2.8, 'Pluto':39.5}
moon2 = {'Haumea':43.2, 'Eris':67.8,'Sedna':506.8}
moonList = [moon1,moon2]
df2 = pd.DataFrame(moonList, index=['first', 'second'])
print(df2)

print(25*'*')
mseries = {'Dwarfs' : pd.Series(['Ceres', 'Pluto'], index=['dwarf1', 'dwarf2'])}
df1 = pd.DataFrame(mseries)
print(df1)

print(25*'*')
moonseries = {'one' : pd.Series(['Ceres', 'Pluto'], index=['a', 'b']),
   'two' : pd.Series(['Haumea','Eris','Sedna'], index=['a', 'b', 'c'])}
dfseries = pd.DataFrame(moonseries)
dfseries['three'] = pd.Series(['Quaoar','Gonggong','Makemake'],index=['a','b','c'])
dfseries['four'] = dfseries['one'] + dfseries['three']
dfseries['two'].append(dfseries['four'])
print(dfseries)

print(25*'*')
del dfseries['one']
print(dfseries)



