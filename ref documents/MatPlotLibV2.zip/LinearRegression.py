import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import linregress

df = pd.read_csv("data.csv")
x = df.X
y = df.Y
stats = linregress(x, y)
pred = stats.slope * x + stats.intercept
plt.scatter(x, y)
plt.plot(x, pred, color="red") 

plt.show()