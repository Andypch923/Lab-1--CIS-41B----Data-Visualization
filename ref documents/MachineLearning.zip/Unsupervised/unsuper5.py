'''
Univariate Anomaly Detection

Anomaly detection is the process of identifying unexpected items or 
events in data sets, which differ from the norm. And anomaly detection 
is often applied on unlabeled data which is known as unsupervised 
anomaly detection. Anomaly detection has two basic assumptions:
* Anomalies only occur very rarely in the data.
* Their features differ from the normal instances significantly.
'''

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib
from sklearn.ensemble import IsolationForest

df = pd.read_excel("Superstore.xlsx")

'''
The Superstore’s sales distribution is far from a normal distribution, 
and it has a positive long thin tail. The mass of the distribution is 
concentrated on the left of the figure. The tail sales distribution far 
exceeds the tails of the normal distribution. There is one region where 
the data has low probability to appear which is on the right side of the 
distribution.
'''
df['Sales'].describe()
plt.scatter(range(df.shape[0]), np.sort(df['Sales'].values))
plt.xlabel('index')
plt.ylabel('Sales')
plt.title("Sales distribution")
sns.despine()
plt.show()

'''
The Superstore’s Profit distribution has both a positive tail and 
negative tail. However, the positive tail is longer than the negative 
tail. So the distribution is positive skewed, and the data are 
heavy-tailed or profusion of outliers. There are two regions where 
the data has low probability to appear: one on the right side of the 
distribution, another one on the left.
'''
df['Profit'].describe()
plt.scatter(range(df.shape[0]), np.sort(df['Profit'].values))
plt.xlabel('index')
plt.ylabel('Profit')
plt.title("Profit distribution")
sns.despine()
plt.show()

sns.distplot(df['Profit'])
plt.title("Distribution of Profit")
sns.despine()

plt.show()