import scipy as sp
import matplotlib.pylab as plt

t = sp.linspace(-1, 1, 100)
plt.plot(t, t**2)

plt.show()